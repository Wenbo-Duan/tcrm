#!/bin/bash

$PYTHON setup.py install || exit 1
